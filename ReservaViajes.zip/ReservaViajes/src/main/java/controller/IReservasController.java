package controller;

public interface IReservasController {
	
	public String listarReservas(String username);

}